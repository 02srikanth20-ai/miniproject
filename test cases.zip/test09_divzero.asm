; Failure test: division by zero must be reported by emulator.
        ldc 42
        ldc 0
        div
        HALT
        ldc 6
ldc 7
mul
ldc 2
div
HALT
