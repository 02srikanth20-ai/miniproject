; Success test for mul and div.
; Expected final A = 21.
        ldc 6
        ldc 7
        mul
        ldc 2
        div
        HALT
